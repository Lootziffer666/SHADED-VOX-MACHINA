package androidx.tracing;

/* JADX INFO: loaded from: classes.dex */
public final class R {
    private R() {
    }
}
